create view jabatan as
select `apps_kolam`.`kods_jabatan`.`idjabatan`   AS `idjabatan`,
       `apps_kolam`.`kods_jabatan`.`namajabatan` AS `namajabatan`
from `apps_kolam`.`kods_jabatan`;

