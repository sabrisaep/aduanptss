create view pegawai as
select `apps_kolam`.`staf`.`idstaf`    AS `idpegawai`,
       `apps_kolam`.`staf`.`jabatan`   AS `jabatan`,
       `apps_kolam`.`staf`.`jawatan`   AS `jawatan`,
       `apps_kolam`.`staf`.`namastaf`  AS `namapegawai`,
       `apps_kolam`.`staf`.`nokpstaf`  AS `nokppegawai`,
       `apps_kolam`.`staf`.`kata`      AS `kata`,
       `apps_kolam`.`staf`.`emailstaf` AS `emelpegawai`
from `apps_kolam`.`staf`;

