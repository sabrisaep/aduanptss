create view jawatan as
select `apps_kolam`.`kods_jawatan`.`idjawatan`   AS `idjawatan`,
       `apps_kolam`.`kods_jawatan`.`namajawatan` AS `namajawatan`
from `apps_kolam`.`kods_jawatan`;

